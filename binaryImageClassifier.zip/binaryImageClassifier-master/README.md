# binaryImageClassifier
This is Tensorflow bases implementation of Convolution Neural Network (CNN) machine learning model.
